the texture is dark because i edit the model on blender

n im bored lol