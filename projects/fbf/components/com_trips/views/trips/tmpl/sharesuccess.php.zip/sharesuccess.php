<div class="innerpage_banner2">
       <div class="item"><img src="images/pro.png" alt=""></div>
</div>
<?php
$db = JFactory::getDbo();
	$status=$_POST["status"];
	$firstname=$_POST["firstname"];
	$amount=$_POST["amount"];
	$txnid=$_POST["txnid"];
	$posted_hash=$_POST["hash"];
	$key=$_POST["key"];
	$productinfo=$_POST["productinfo"];
	$email=$_POST["email"];
	$phone=$_POST["phone"];
	$salt="Zv4aHtx68w";

    $oid = JRequest::getvar('oid');

// Salt should be same Post Request

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
  } else {
        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
         }
		 $hash = hash("sha512", $retHashSeq);
       if ($hash != $posted_hash) {
	       echo "Invalid Transaction. Please try again";
		   } else {

		   	// Action
		   	
		   	if($productinfo==1){
		   	    $trip_type='customized';
        		$paymentlink=''.JURI::root().'share-payment/?oid='.$oid.'&t=1';
        		$sqlx="SELECT * FROM `#__customized_order` WHERE id=$oid";
        		$db->setQuery($sqlx);
        		$final_detail=$db->loadObjectList();
        		foreach($final_detail as $finalqute_disp) {
        		     $orderid=$finalqute_disp->id;
        		     $payment_type=$finalqute_disp->payment_type;
        		     $organizer_id=$finalqute_disp->uid;
        		}
		   	} else if($productinfo==2) {
		   	    $trip_type='semi';
		   	   	$paymentlink=''.JURI::root().'share-payment/?oid='.$oid.'&t=2';
        		$sqlx="SELECT * FROM `#__semicustomized_order` WHERE id=$oid";
        		$db->setQuery($sqlx);
        		$final_detail=$db->loadObjectList();
        		foreach($final_detail as $finalqute_disp) {
        		     $orderid=$finalqute_disp->id;
        		     $payment_type=$finalqute_disp->payment_type;
        		     $organizer_id=$finalqute_disp->uid;
        		} 
		   	    
		   	} else if($productinfo==3) {
		   	    $trip_type='fixed';
		   	   	$paymentlink=''.JURI::root().'share-payment/?oid='.$oid.'&t=3';
        		$sqlx="SELECT * FROM `#__fixed_trip_orders` WHERE id=$oid";
        		$db->setQuery($sqlx);
        		$final_detail=$db->loadObjectList();
        		foreach($final_detail as $finalqute_disp) {
        		     $orderid=$finalqute_disp->id;
        		     $payment_type=$finalqute_disp->payment_type;
        		     $organizer_id=$finalqute_disp->uid;
        		} 
		   	}
		   	
		$paidsql="SELECT COUNT(id) FROM `#__sharepayment` WHERE txnid='$txnid'";
		$db->setQuery($paidsql);
		$paidcount=$db->loadResult();

		 if($paidcount==0) {
			$date = date('Y-m-d H:i:s');
			$object = new stdClass();
			$object->id = '';
			$object->pay_status ='first';
			$object->organizer_id =$organizer_id;
			$object->trip_type =$trip_type;
			$object->payment_type  =$payment_type;
			$object->orderid  =$oid;
			$object->friendname  =$firstname;
			$object->friendemail  =$email;
			$object->friendnum  =$phone;
			$object->paymentlink  =$paymentlink;
			$object->paid_amt  =$amount;
			$object->txnid  =$txnid;
			$result =$db->insertObject('#__sharepayment', $object);
			}

          echo "<h3>Thank You. Your order status is ". $status .".</h3>";
          echo "<h4>Your Transaction ID for this transaction is ".$txnid.".</h4>";
          echo "<h4>We have received a payment of Rs. " . $amount . ". Your order will soon be shipped.</h4>";
		   }
?>