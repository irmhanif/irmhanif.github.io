var tabs = angular.module('tabs', [])
.controller('tabCtrl', function ($scope) {
    $scope.selected = "1";
});