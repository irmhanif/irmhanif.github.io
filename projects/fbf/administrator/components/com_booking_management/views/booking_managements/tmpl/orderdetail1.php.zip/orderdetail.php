<p class="bklink">
	<a href="index.php?option=com_booking_management&view=booking_managements">BACK</a>
</p>

    <?php
	$db = JFactory::getDbo();
	$id = JRequest::getVar('id');
	$qts = JRequest::getVar('qts');
	$userid = JRequest::getVar('userid');

	$getorderdetails2="SELECT * FROM `#__semicustomized_order` WHERE uid=$userid AND quote_status=$qts";
	$db->setQuery($getorderdetails2);
	$orderdetail2=$db->loadObjectList();

	foreach($orderdetail2 as $orderdetail2_disp) {
	    $updateid=$orderdetail2_disp->id;
	}


    $sqllist="SELECT * FROM `#__semicustomized_order` WHERE  id=$id AND ((payment_status='finalizebyuser') || (trip_status='quotation')) AND quote_status=$qts";
    $db->setQuery($sqllist);
    $result=$db->loadObjectList();
    foreach($result as $data)
    {
	$uid=$data->uid;
	$oid=$data->id;
	$booked_time=$data->booked_time;
	$payer_name=$data->payer_name;
	$no_days=$data->noofdays;
	$no_people=$data->number_peoples;
	$no_rooms=$data->number_rooms;
	$transport=$data->transport;
	$flight=$data->flight;
	$keeper=$data->keeper_information;
	$hotel=$data->hotel;
	$total_cost_tax_free=$data->total_cost_tax_free;
	$added_date=$data->added_date;
	$trip_id=$data->trip_id;
	$comment=$data->comment;

  $paydate1=$data->pay_date1;
  $txnid=$data->txnid;
  $paydate2=$data->pay_date2;
  $txnid2=$data->txnid2;

  $paytime1 = date ('H:i', strtotime($paydate1));
  $paydate1 = date ('Y-m-d', strtotime($paydate1));
  $paytime2 = date ('H:i', strtotime($paydate2));
  $paydate2 = date ('Y-m-d', strtotime($paydate2));

	$sqltripdet="SELECT * FROM `#__semicustomized_trip` WHERE  id=$trip_id";
    $db->setQuery($sqltripdet);
    $tripdetails=$db->loadObjectList();

    foreach ($tripdetails as $tripdetails_disp) {
    	$title=$tripdetails_disp->title;
    	$category=$tripdetails_disp->carrousselselection;
    }


	$flight_amount=$data->cost_of_flight_ticket;
	if($flight_amount==0) {
		$flight_amount='';
	}

	$price_of_hotel=$data->price_of_hotel;
		if($price_of_hotel==0) {
			$price_of_hotel='';
		}


	$cost_of_activities=$data->cost_of_activities;
	if($cost_of_activities==0) {
		$cost_of_activities='';
	}
	$cost_of_transport=$data->cost_of_transport;
	if($cost_of_transport==0) {
		$cost_of_transport='';
	}

	$cost_of_Keeper = $data->cost_of_Keeper;
	if($cost_of_Keeper==0) {
		$cost_of_Keeper='';
	}
	$cost_of_booking_Fee=$data->cost_of_booking_fee;
	if($cost_of_booking_Fee==0) {
		$cost_of_booking_Fee='';
	}
	$cost_of_insurance=$data->cost_of_insurance;
	if($cost_of_insurance==0) {
		$cost_of_insurance='';
	}
	$total_amount_for_filght=$data->total_amount_for_filght;
	if($total_amount_for_filght==0) {
		$total_amount_for_filght='';
	}

	$total_cost_tax_free=$data->total_cost_tax_free;
	if($total_cost_tax_free==0) {
		$total_cost_tax_free='';
	}

	$gstamount=$data->gst;
	if($gstamount==0) {
		$gstamount='';
	}
	$final_cost=$data->final_cost;
	if($final_cost==0) {
		$final_cost='';
	}

	$first_installement=$data->first_installement;
	if($first_installement==0) {
		$first_installement='';
	}

	$last_day_for_first_installement=$data->last_day_for_first_installement;
	if($last_day_for_first_installement==0) {
		$last_day_for_first_installement='';
	}

	$final_installement=$data->final_installement;
	if($final_installement== 0) {
		$final_installement='';
	}

	$last_day_for_final_installement=$data->last_day_for_final_installement;

	if($last_day_for_final_installement == 0) {
		$last_day_for_final_installement='';
	}

	$sql="SELECT * FROM `#__users` WHERE id=$uid";
	$db->setQuery($sql);
	$events_detail=$db->loadObjectList();
	foreach($events_detail as $event_disp) {
	    $userid=$event_disp->id;
		$username=$event_disp->name;
		$contact=$event_disp->phone;
		$mail=$event_disp->email;
	}
}

  $lastfirstpaytime = date('H:i', strtotime($last_day_for_first_installement));
  $lastfinalpaytime = date('H:i', strtotime($last_day_for_final_installement));
  $last_day_for_first_installement = date('d-m-Y', strtotime($last_day_for_first_installement));
$last_day_for_final_installement = date('d-m-Y', strtotime($last_day_for_final_installement));
/* getting other packages */

	echo '<div class="customerdetails">
			<p><span class="cusname">Name : '.$username.'</span><span class="cusnum">Number : '.$contact.'</span><span class="cusname">Email : '.$mail.'</span></p>
	</div>';

	$gettinother="SELECT COUNT(id) FROM `#__semicustomized_order` WHERE uid=$uid AND id!=$id AND ((payment_status='finalizebyuser') || (trip_status='quotation')) AND quote_status=$qts";
    $db->setQuery($gettinother);
    $gettinotherres_count=$db->loadResult();



    $sqllist2="SELECT * FROM `#__semicustomized_order` WHERE uid=$uid AND id!=$id AND ((payment_status='finalizebyuser') || (trip_status='quotation')) AND quote_status=$qts";
    $db->setQuery($sqllist2);
    $result2=$db->loadObjectList();

    foreach($result2 as $otherdata)
    {
        $idz=$otherdata->id;
		$booked_time2=$otherdata->booked_time;
		$uid=$otherdata->uid;
		$trip_id2=$otherdata->trip_id;
		$payer_name2=$otherdata->payer_name;
		$no_days2=$otherdata->noofdays;
		$no_people2=$otherdata->number_peoples;
		$no_rooms2=$otherdata->number_rooms;
		$transport2=$otherdata->transport;
		$flight2=$otherdata->flight;
		$keeper2=$otherdata->keeper_information;
		$hotel2=$otherdata->hotel;
		$total_cost_tax_free2=$otherdata->total_cost_tax_free;
		$added_date2=$otherdata->added_date;
		$comment2=$otherdata->comment;

	$sqltripdet2="SELECT * FROM `#__semicustomized_trip` WHERE  id=$trip_id2";
    $db->setQuery($sqltripdet2);
    $tripdetails2=$db->loadObjectList();

    foreach ($tripdetails2 as $tripdetails_disp2) {
    	$title2=$tripdetails_disp2->title;
    	$category2=$tripdetails_disp2->carrousselselection;
    }


		echo '<div class="packages">
		  <p>
              <span class="leftlabel">Package Tittle 1</span>
              <span class="righttext">'.$title2.'</span>
          </p>
		  <p>
              <span class="leftlabel">Category</span>
              <span class="righttext">'.$category2.'</span>
          </p>
          <p>
              <span class="leftlabel">Total Price 2</span>
              <span class="righttext">'.$total_cost_tax_free2.'</span>
          </p>
          <p>
              <span class="leftlabel">Transport</span>
              <span class="righttext">'.$transport2.'</span>
          </p>
          <p>
              <span class="leftlabel">Keeper</span>
              <span class="righttext">'.$keeper2.'</span>
          </p>
          <p>
              <span class="leftlabel">Flight</span>
              <span class="righttext">'.$flight2.'</span>
          </p>
          <p>
              <span class="leftlabel">No of People</span>
              <span class="righttext">'.$no_people2.'</span>
          </p>
          <p>
              <span class="leftlabel">No Of Room</span>
              <span class="righttext">'.$no_rooms2.'</span>
          </p>
           <p>
              <span class="leftlabel">No Of days</span>
              <span class="righttext">'.$no_days2.'</span>
          </p></div>';
    }


	$sqlgst="SELECT * FROM `#__common_price_management` WHERE state=1";
	$db->setQuery($sqlgst);
	$common_price_management_detail=$db->loadObjectList();
	foreach($common_price_management_detail as $pricemgt_disp) {
	    $gst=$pricemgt_disp->gst;
	}
?>

<link rel="stylesheet" href="addons/date/css/style.css">

<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css'>

	<div class="packages">
	      <p>
              <span class="leftlabel">Package Tittle</span>
              <span class="righttext"><?php echo $title; ?></span>
          </p>
		  <p>
              <span class="leftlabel">Category</span>
              <span class="righttext"><?php echo $category; ?></span>
          </p>
          <p>
              <span class="leftlabel">Total Price</span>
              <span class="righttext"><?php echo $total_cost_tax_free; ?></span>
          </p>
          <p>
              <span class="leftlabel">Transport</span>
              <span class="righttext"><?php echo $transport; ?></span>
          </p>
          <p>
              <span class="leftlabel">Keeper</span>
              <span class="righttext"><?php echo $keeper; ?></span>
          </p>
          <p>
              <span class="leftlabel">Flight</span>
              <span class="righttext"><?php echo $flight; ?></span>
          </p>
          <p>
              <span class="leftlabel">No of People</span>
              <span class="righttext"><?php echo $no_people; ?></span>
          </p>
          <p>
              <span class="leftlabel">No Of Room</span>
              <span class="righttext"><?php echo $no_rooms; ?></span>
          </p>
           <p>
              <span class="leftlabel">No Of days</span>
              <span class="righttext"><?php echo $no_days; ?></span>
          </p>

	</div>

	<?php
	//get price
	$price_of_hotelall='';
	$cost_of_activitiesall='';
	$cost_of_transportall='';
	$cost_of_Keeperall='';
	$cost_of_booking_Feeall='';
	$cost_of_insuranceall='';
	$total_cost_tax_freeall='';
	$final_costall='';
	$gstamountall='';
	$total_cost_tax_freeall='';
	$transfer_departure_priceall='';
	$price_of_leavingall='';
	$price_of_public_transportall='';

	$sqlprice2="SELECT * FROM `#__semicustomized_order` WHERE uid=$uid AND ((payment_status='finalizebyuser') || (trip_status='quotation')) AND quote_status=$qts";
    $db->setQuery($sqlprice2);
    $result3=$db->loadObjectList();
    foreach($result3 as $priceotherdata)
    {
		 $price_of_hotelall+=$priceotherdata->price_of_hotel;
		if($price_of_hotelall==0) {
			$price_of_hotelall='';
		}
		$cost_of_activitiesall+=$priceotherdata->cost_of_activities;
		if($cost_of_activitiesall==0) {
			$cost_of_activitiesall='';
		}
		$cost_of_transportall+=$priceotherdata->cost_of_transport;
		if($cost_of_transportall==0) {
			$cost_of_transportall='';
		}
		$cost_of_Keeperall+= $priceotherdata->cost_of_Keeper;
		if($cost_of_Keeperall==0) {
			$cost_of_Keeperall='';
		}
		$cost_of_booking_Feeall+=$priceotherdata->cost_of_booking_fee;
		if($cost_of_booking_Fee==0) {
			$cost_of_booking_Feeall='';
		}
		$cost_of_insuranceall+=$priceotherdata->cost_of_insurance;
		if($cost_of_insuranceall==0) {
			$cost_of_insuranceall='';
		}
	    $transfer_departure_priceall+=$priceotherdata->transfer_departure_price;
		if($transfer_departure_priceall==0) {
			$transfer_departure_priceall='';
		}
	    $price_of_leavingall+=$priceotherdata->price_of_leaving;
		if($price_of_leavingall==0) {
			$price_of_leavingall='';
		}
	    $price_of_public_transportall+=$priceotherdata->price_of_public_transport;
		if($price_of_public_transportall==0) {
			$price_of_public_transportall='';
		}

		 $total_cost_tax_freeall+=$priceotherdata->total_cost_tax_free;
		if($total_cost_tax_freeall==0) {
			$total_cost_tax_freeall='';
		}
		$gstamountall+=$priceotherdata->gst;
		if($gstamountall==0) {
			$gstamountall='';
		}
		$final_costall+=$priceotherdata->final_cost;
		if($final_costall==0) {
			$final_costall='';
		}
    }
	?>

    <div class="display_book_detail">
      <form action="#" Method="POST" name="bookingform" id="bookingform">
          <p>
              <span class="leftlabel">Flight Amount Per Person</span>
              <span class="righttext"><input value="<?php echo $flight_amount; ?>" type="text" id="flight_amount" name="flight_amount" /></span>
          </p>
          <p>
              <span class="leftlabel">Price Of Hotel</span>
              <span class="righttext"><input value="<?php echo $price_of_hotelall; ?>" type="text" id="price_of_hotel" name="price_of_hotel" /></span>
          </p>
          <p>
              <span class="leftlabel">Cost of transport</span>
              <span class="righttext"><input value="<?php echo $cost_of_transportall; ?>" type="text" id="cost_of_transport" name="cost_of_transport" /></span>
          </p>
          <p>
              <span class="leftlabel">Cost of Keeper</span>
              <span class="righttext"><input value="<?php echo $cost_of_Keeperall; ?>" type="text" id="cost_of_Keeper" name="cost_of_Keeper" /></span>
          </p>
          <p>
              <span class="leftlabel">Cost of activities</span>
              <span class="righttext"><input value="<?php echo $cost_of_activitiesall; ?>" type="text" id="cost_of_activities" name="cost_of_activities" /></span>
          </p>
          <p>
              <span class="leftlabel">Transfer Departure Price</span>
              <span class="righttext"><input value="<?php echo $transfer_departure_priceall; ?>" type="text" id="transfer_departure_price" name="transfer_departure_price" /></span>
          </p>
           <p>
              <span class="leftlabel">Price Of Leaving</span>
              <span class="righttext"><input value="<?php echo $price_of_leavingall; ?>" type="text" id="price_of_leaving" name="price_of_leaving" /></span>
          </p>
          <p>
              <span class="leftlabel">Price Of Public Transport</span>
              <span class="righttext"><input value="<?php echo $price_of_public_transportall; ?>" type="text" id="price_of_public_transport" name="price_of_public_transport" /></span>
          </p>
          <p>
              <span class="leftlabel">Cost of booking Fee</span>
              <span class="righttext"><input value="<?php echo $cost_of_booking_Feeall; ?>" type="text" id="cost_of_booking_Fee" name="cost_of_booking_Fee" /></span>
          </p>

          <p>
              <span class="leftlabel">Cost of Insurance</span>
              <span class="righttext"><input value="<?php echo $cost_of_insuranceall; ?>" type="text" id="cost_of_insurance" name="cost_of_insurance" /></span>
          </p>
           <p>
              <span class="leftlabel">Total Flight Amount</span>
              <span class="righttext"><input value="<?php echo $total_amount_for_filght; ?>" type="text" id="tflight_amount" name="tflight_amount" /></span>
          </p>
           <p>
          		<input type="button" value="Calculate total" id="totalamt">
           </p>
          <p>
              <span class="leftlabel">Total Cost Tax Free</span>
              <span class="righttext"><input value="<?php echo $total_cost_tax_freeall; ?>" type="text" id="total_cost_tax_free" name="total_cost_tax_free" /></span>
          </p>
          <p>
              <span class="leftlabel">Gst</span>
              <span class="righttext"><input value="<?php echo $gstamountall/$no_people2; ?>" type="text" id="gst" name="gst" /></span>
          </p>
          <p>
              <span class="leftlabel">Final cost </span>
              <span class="righttext"><input value="<?php echo $final_costall/$no_people2; ?>" type="text" id="final_cost" name="final_cost" /></span>
          </p>
          <p>
              <span class="leftlabel">First Installment</span>
              <span class="righttext"><input value="<?php echo $first_installement/$no_people2; ?>" type="text" id="first_installement" name="first_installement" /></span>
          </p>
           <p>
              <span class="leftlabel">Last Day to send First Installement</span>
              <span class="righttext"><input value="<?php echo $last_day_for_first_installement; ?>" type="text" id="last_day_for_first_installement" name="last_day_for_first_installement" /></span>
              <span class="righttext"><input value="<?php echo $lastfirstpaytime; ?>" type="time" id="lastfirstpaytime" name="lastfirstpaytime" /></span>
          </p>
          <p>
              <span class="leftlabel">Final Installment</span>
              <span class="righttext"><input value="<?php echo $final_installement; ?>" type="text" id="final_installement" name="final_installement" /></span>
          </p>
           <p>
              <span class="leftlabel">Last Day to send Final Installement</span>
              <span class="righttext"><input value="<?php echo $last_day_for_final_installement; ?>" type="text" id="last_day_for_final_installement" name="last_day_for_final_installement" /></span>
              <span class="righttext"><input value="<?php echo $lastfinalpaytime; ?>" type="time" id="lastfinalpaytime" name="lastfinalpaytime" /></span>
          </p>
          <p>
              <span class="leftlabel">Comment</span>
              <span class="righttext"><textarea rows="4" cols="50" id="comment"> <?php echo $comment; ?> </textarea></span>
          </p>
          <input type="button" value="Update" id="update">

          <p>
              <span class="leftlabel">First Installment payment Date and time</span>
              <span class="righttext"><input value="<?php echo $paydate1; ?>" type="date" id="paydate1" name="paydate1" /></span>
          </p>
          <p>
              <span class="leftlabel">First Installment payment time</span>
              <span class="righttext"><input value="<?php echo $paytime1; ?>" type="time" id="paytime1" name="paytime1" /></span>
          </p>
          <p>
              <span class="leftlabel">First Installment Transaction id</span>
              <span class="righttext"><input value="<?php echo $txnid; ?>" type="text" id="txnid" name="txnid" /></span>
          </p>
          <p>
          <input type="button" value="First installment Update" id="firstupdate">
          </p>

          <p>
              <span class="leftlabel">Final Installment payment Date and time</span>
              <span class="righttext"><input value="<?php echo $paydate2; ?>" type="date" id="paydate2" name="paydate2" /></span>
          </p>
          <p>
              <span class="leftlabel">Final Installment payment time</span>
              <span class="righttext"><input value="<?php echo $paytime2; ?>" type="time" id="paytime2" name="paytime2" /></span>
          </p>
          <p>
              <span class="leftlabel">Final Installment Transaction id</span>
              <span class="righttext"><input value="<?php echo $txnid2; ?>" type="text" id="txnid2" name="txnid2" /></span>
          </p>
          <p>
          <input type="button" value="Final installment Update" id="finalupdate">
          </p>
      </from>

      <p id="msgdisp"></p>

    </div>

<?php
    $doc_files='';
    $doc="SELECT * FROM `#__user_documents` WHERE oid=$oid AND trip_type='semi'";
    $doc1="SELECT COUNT(id) FROM `#__user_documents` WHERE oid=$oid AND trip_type='semi'";
    if($oid!==0){
    $db->setQuery($doc);
    $disp=$db->loadObjectList();

foreach($disp as $doc_file)
{
	$uid=$doc_file->user_id;
	$id=$doc_file->id;
	$oid=$doc_file->oid;
	$document=$doc_file->document;
	$pancard=$doc_file->pancard;
	$tshirt=$doc_file->tshirt;
	$trip_type=$doc_file->trip_type;
	$address=$doc_file->address;

	$del=rtrim($document,',');/*remove last comma*/
	$passport=(explode(",",$del));
    $passport_file=array_filter($passport);
    $pass_image=array_values($passport_file);


	$des=rtrim($pancard,',');/*remove last comma*/
	$pandetail=(explode(",",$des));
    $pancard_file=array_filter($pandetail);
    $pancard_image=array_values($pancard_file);

	$tshirt_size=rtrim($tshirt,',');
	$tshirt_detail=(explode(",",$tshirt_size));
    $pancard_file1=array_filter($tshirt_detail);
    $pancard_image1=array_values($pancard_file1);

	 for($i=0;$i<sizeof($pass_image);$i++){

	echo '<div class="res_d">' .
			'<table>
				  <tr><td><a href="images/documents/'.$uid.'/'.$pass_image[$i].'" download >Download Passport '.$i.'</a></td></tr>
				  <tr><td><a href="images/pandocument/'.$uid.'/'.$pancard_image[$i].'" download >Download PanCard '.$i.'</a><td></tr>
				  <tr><td><span class="quote_value">'.$trip_type.'</span><td></tr>
				  <tr><td><span class="quote_value">'.$pancard_image1[$i].'</span><td></tr>
	 		</table> </div>';
	 /*<img src="'.JURI::root().'images/documents/'.$uid.'/'.$pass_image[$i].'" />*/

	}
}
echo '<div class="res_d"><p>Address: '.$address.'</p></div>';
}
else{
    echo"";
}
?>

<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js'></script>

<script>
	var dateToday = new Date();
	jQuery(document).ready(function(){
	  jQuery("#last_day_for_first_installement").datepicker({
	      format: 'dd-mm-yyyy',
	        autoclose: true,
	        startDate: "+0d" ,
	        todayHighlight: true
	  });
	 jQuery("#last_day_for_final_installement").datepicker({
	      format: 'dd-mm-yyyy',
	        autoclose: true,
	        startDate: "+0d" ,
	        todayHighlight: true
	  });
	});
	</script>

<script>
jQuery(document).ready(function(){
	jQuery("#update").click(function(){
	    var flight_amount = jQuery("#flight_amount").val();
	    var price_of_hotel = jQuery("#price_of_hotel").val();
	    var first_installement = jQuery("#first_installement").val();
	    var last_day_for_first_installement = jQuery("#last_day_for_first_installement").val();
	    var final_installement = jQuery("#final_installement").val();
	    var last_day_for_final_installement = jQuery("#last_day_for_final_installement").val();
	    var orderid = <?php echo $updateid; ?>;
	    var uid = <?php echo $uid; ?>;

	    if(flight_amount=='') {
	       jQuery("#flight_amount").focus();
	       jQuery("#flight_amount").css("border","1px solid red");
	       return false;
	    } else if(first_installement=='') {
	       jQuery("#first_installement").focus();
	       jQuery("#first_installement").css("border","1px solid red");
	       return false;
	    } else if(last_day_for_first_installement=='') {
	       jQuery("#last_day_for_first_installement").focus();
	       jQuery("#last_day_for_first_installement").css("border","1px solid red");
	       return false;
	    } else if(final_installement=='') {
	       jQuery("#final_installement").focus();
	       jQuery("#final_installement").css("border","1px solid red");
	       return false;
	    } else if(last_day_for_final_installement=='') {
	       jQuery("#last_day_for_final_installement").focus();
	       jQuery("#last_day_for_final_installement").css("border","1px solid red");
	       return false;
	    }  else {
	        var cost_of_activities = jQuery("#cost_of_activities").val();
		    var cost_of_transport = jQuery("#cost_of_transport").val();
		    var cost_of_Keeper = jQuery("#cost_of_Keeper").val();
		    var cost_of_booking_Fee = jQuery("#cost_of_booking_Fee").val();
		    var cost_of_insurance = jQuery("#cost_of_insurance").val();
		    var total_cost_tax_free = jQuery("#total_cost_tax_free").val();
		    var gst = jQuery("#gst").val();
		    var final_cost = jQuery("#final_cost").val();
		    var comment = jQuery("#comment").val();
		    var total_amount_for_filght = jQuery("#tflight_amount").val();
		    var lastfirstpaytime = jQuery("#lastfirstpaytime").val();
            var lastfinalpaytime = jQuery("#lastfinalpaytime").val();
		    jQuery.post("index.php?option=com_booking_management&task=booking_managements.amountUpdateForSemicustomized&flight_amount="+flight_amount+"&lastfirstpaytime="+lastfirstpaytime+"&lastfinalpaytime="+lastfinalpaytime+"&orderid="+orderid+"&first_installement="+first_installement+"&last_day_for_first_installement="+last_day_for_first_installement+"&final_installement="+final_installement+"&last_day_for_final_installement="+last_day_for_final_installement+"&final_cost="+final_cost+"&comment="+comment+"&uid="+uid+"&total_amount_for_filght="+total_amount_for_filght,updateMsg);
	    }
	});
jQuery("#firstupdate").click(function(){
    var orderid = <?php echo $updateid; ?>;
      var first_installment__payed_date = jQuery("#paydate1").val();
      var first_installment__payed_time = jQuery("#paytime1").val();
      var first_installment_txnid = jQuery("#txnid").val();
      jQuery.post("index.php?option=com_booking_management&task=booking_managements.semi_order_firstupdate&orderid="+orderid+"&first_installment__payed_date="+first_installment__payed_date+"&first_installment__payed_time="+first_installment__payed_time+"&first_installment_txnid="+first_installment_txnid,updateMsg1);
  });
  jQuery("#finalupdate").click(function(){
    var orderid = <?php echo $updateid; ?>;

      var final_installment__payed_date = jQuery("#paydate2").val();
      var final_installment__payed_time = jQuery("#paytime2").val();
      var final_installment_txnid = jQuery("#txnid2").val();
      jQuery.post("index.php?option=com_booking_management&task=booking_managements.semi_order_finalupdate&orderid="+orderid+"&final_installment__payed_date="+final_installment__payed_date+"&final_installment__payed_time="+final_installment__payed_time+"&final_installment_txnid="+final_installment_txnid,updateMsg2);
  });
	function updateMsg(stext,status){
	   if(status=="success"){
		   jQuery("#msgdisp").html("Updated successfully");
	    }
   }
   function updateMsg1(stext,status){
	   if(status=="success"){
		   jQuery("#msgdisp").html("Updated successfully");
	    }
   }
   function updateMsg2(stext,status){
	   if(status=="success"){
		   jQuery("#msgdisp").html("Updated successfully");
	    }
   }

	jQuery("#totalamt").click(function(){
	    var flight_amount = jQuery("#flight_amount").val();
	    var photel = jQuery("#price_of_hotel").val();
	    var c_transport = jQuery("#cost_of_transport").val();
	    var c_Keeper = jQuery("#cost_of_Keeper").val();
	    var c_activities = jQuery("#cost_of_activities").val();
	    var transfer_departure_price = jQuery("#transfer_departure_price").val();
	    var price_of_leaving = jQuery("#price_of_leaving").val();
	    var price_of_public_transport = jQuery("#price_of_public_transport").val();
	    var c_booking_Fee = jQuery("#cost_of_booking_Fee").val();
	    var c_insurance = jQuery("#cost_of_insurance").val();

	    var gst = <?php echo $gst; ?>;
	    var no_people=<?php echo $no_people; ?>;

	    var flight_amount_all = parseInt(flight_amount)*parseInt(no_people);

	    if(flight_amount=='') {
	       jQuery("#flight_amount").focus();
	       jQuery("#flight_amount").css("border","1px solid red");
	        return false;
	    } else {
	    	jQuery("#tflight_amount").val(flight_amount_all);

	    	if(transfer_departure_price==''){
	    		transfer_departure_price=0;
	    	}
	    	if(price_of_leaving==''){
	    		price_of_leaving=0;
	    	}
	    	if(price_of_public_transport=='') {
	    		price_of_public_transport=0;
	    	}


		    var total_cost_tax_free = parseInt(flight_amount_all)+parseInt(photel)+parseInt(c_transport)+parseInt(c_Keeper)+parseInt(c_activities)+parseInt(transfer_departure_price)+parseInt(price_of_leaving)+parseInt(price_of_public_transport)+parseInt(c_booking_Fee)+parseInt(c_insurance);

			jQuery("#total_cost_tax_free").val(total_cost_tax_free);

			var gstamt = (parseInt(gst) / 100) * parseInt(total_cost_tax_free);
			jQuery("#gst").val(Math.round(gstamt));
			var amount_wittax=parseInt(gstamt)+parseInt(total_cost_tax_free);
			jQuery("#final_cost").val(amount_wittax);
	    }
	});
});

</script>

<style>
.display_book_detail {
  float: left;
  width: 50%;
}
.leftlabel {
  float: left;
  font-weight: bold;
  width: 30%;
}
.btn-toolbar {
  display: none;
}
.packages {
  float: left;
  width: 50%;
}
.packages {
  background: #f0f0f0 none repeat scroll 0 0;
  float: left;
  margin-right: 3%;
  padding: 2%;
  width: 41%;
}
#update {
  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
  border: 1px solid #f04d33;
  color: #f04d33;
  float: left;
  font-size: 17px;
  padding: 0.4em 0;
  width: 25%;
}
.customerdetails span {
  font-size: 18px;
  margin-right: 2em;
}
.customerdetails {
  float: left;
  width: 100%;
}
.packages .leftlabel {
  float: left;
  width: 54%;
}
.packages p {
  float: left;
  width: 50%;
}
#bookingform p {
  float: left;
  width: 100%;
}
.display_book_detail {
  float: left;
  margin: 1% 0;
  width: 50%;
}
.display_book_detail {
  float: left;
  width: 50%;
}
.leftlabel {
  float: left;
  font-weight: bold;
  width: 30%;
}
.btn-toolbar {
  display: none;
}
#update {
  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
  border: 1px solid #f04d33;
  color: #f04d33;
  float: left;
  font-size: 17px;
  padding: 0.4em 0;
  width: 25%;
}
#bookingform p {
  float: left;
  width: 100%;
}
.doc_disp {
	width: 50%;
	float: left;
}
.res_d {
	width: 100%;
	float: left;
}
.res_d table,.res_dd table {
  width:100%;
}


.res_d th, td,.res_dd th, td {
  padding: 15px;
  text-align: left;
}
.res_d table tr {
	width: 18%;
	float: left;
	border: 1px solid #000;
}
.res_d table#t01 th,.res_dd table#t01 th {
  background-color: black;
  color: white;
}
.res_dd table tr {
	width:90.5%;
	float: left;

}
.res_dd table tr th {
	width: 17.29%;
	float: left;
	border: 1px solid #000;
}
</style>